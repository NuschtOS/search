/* tslint:disable */
/* eslint-disable */

export class Index {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  get_idx_by_name(scope_id: number, name: string): number | undefined;
  static read(buf: Uint8Array): Index;
  size(): number;
  search(scope_id: number | null | undefined, query: string, max_results: number): SearchedOption[];
}

export class SearchedOption {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  idx(): number;
  name(): string;
  scope_id(): number;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_index_free: (a: number, b: number) => void;
  readonly __wbg_searchedoption_free: (a: number, b: number) => void;
  readonly index_get_idx_by_name: (a: number, b: number, c: number, d: any) => void;
  readonly index_read: (a: number, b: number, c: number) => void;
  readonly index_search: (a: number, b: number, c: number, d: any, e: number) => void;
  readonly index_size: (a: number) => number;
  readonly searchedoption_idx: (a: number) => number;
  readonly searchedoption_name: (a: number, b: number) => void;
  readonly searchedoption_scope_id: (a: number) => number;
  readonly __wbindgen_export: (a: number, b: number) => number;
  readonly __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_externrefs: WebAssembly.Table;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_export3: (a: number, b: number, c: number) => void;
  readonly __wbindgen_export4: (a: number) => void;
  readonly __wbindgen_export5: (a: number, b: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
